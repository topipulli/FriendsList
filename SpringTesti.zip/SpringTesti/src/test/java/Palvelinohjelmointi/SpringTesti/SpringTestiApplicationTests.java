package Palvelinohjelmointi.SpringTesti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTestiApplicationTests {

	@Test
	void contextLoads() {
	}

}
