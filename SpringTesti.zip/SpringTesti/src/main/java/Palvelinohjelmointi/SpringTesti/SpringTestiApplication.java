package Palvelinohjelmointi.SpringTesti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringTestiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringTestiApplication.class, args);
	}

}
