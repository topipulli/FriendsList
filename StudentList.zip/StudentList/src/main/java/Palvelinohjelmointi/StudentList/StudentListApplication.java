package Palvelinohjelmointi.StudentList;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentListApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentListApplication.class, args);
	}

}
