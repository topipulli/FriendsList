package Palvelinohjelmointi.StudentList;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentListApplicationTests {

	@Test
	void contextLoads() {
	}

}
