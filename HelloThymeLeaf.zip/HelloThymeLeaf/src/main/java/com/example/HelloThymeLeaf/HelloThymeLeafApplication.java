package com.example.HelloThymeLeaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloThymeLeafApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloThymeLeafApplication.class, args);
	}

}
